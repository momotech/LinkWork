"""LinkWork Agent SDK exception hierarchy."""

from __future__ import annotations


class MomoAgentSDKError(Exception):
    """Base error for SDK."""


class ConfigError(MomoAgentSDKError):
    """Base config error."""


class ConfigNotFoundError(ConfigError):
    """Config file does not exist."""


class ConfigNullError(ConfigError):
    """Config file content is empty."""


class ConfigParseError(ConfigError):
    """Config file JSON parsing failed."""


class ConfigValidationError(ConfigError):
    """Config model validation failed."""


class ConfigPermissionError(ConfigError):
    """Config file permission denied."""


class RedisClientError(MomoAgentSDKError):
    """Redis client operation failed."""


class SecurityLoadError(MomoAgentSDKError):
    """Security rules loading failed."""


class SecurityExecuteError(MomoAgentSDKError):
    """Security check execution failed."""


class SkillLoadError(MomoAgentSDKError):
    """Skills loading failed."""


class MCPLoadError(MomoAgentSDKError):
    """MCP config loading failed."""


class ConcurrentExecutionError(MomoAgentSDKError):
    """Concurrent run() is not allowed."""


class RuntimeInitError(MomoAgentSDKError):
    """AI runtime initialization failed."""


class RuntimeProtocolError(MomoAgentSDKError):
    """AI runtime returned protocol-invalid response."""


class WorkerLifecycleError(MomoAgentSDKError):
    """Worker lifecycle operation failed."""
